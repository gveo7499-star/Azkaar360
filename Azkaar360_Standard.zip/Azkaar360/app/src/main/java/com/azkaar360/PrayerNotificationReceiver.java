package com.azkaar360;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerNotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Handle prayer time notifications
        // Implementation for notification display
    }
}
